define(["exports", "../common/FilterViewAPI", "../common/BaseRenderer"], function (_exports, _FilterViewAPI, _BaseRenderer) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  _FilterViewAPI = _interopRequireDefault(_FilterViewAPI);
  _BaseRenderer = _interopRequireDefault(_BaseRenderer);
  function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
  /* ******************************************************** {COPYRIGHT-TOP} ****
   * Copyright IBM Corp. 2024
   * 
   * This source code is licensed under the Apache-2.0 license found in the
   * LICENSE file in the root directory of this source tree.
   ********************************************************* {COPYRIGHT-END} ****/

  const TYPE = 'alert';
  let filtersViewsResult = [];
  async function getFilters(proxyHost) {
    const filterViewAPI = new _FilterViewAPI.default({
      options: ['filter'],
      type: TYPE,
      proxyHost
    });
    filtersViewsResult = await filterViewAPI.getData();
    return Promise.resolve();
  }
  class ButtonDynamicProperty extends _BaseRenderer.default {
    constructor(options) {
      super(options);
      options.features.Properties.registerProvider(this);
    }
    initialize() {
      super.initialize().then(() => {
        return getFilters(this.proxyHost);
      });
    }
    getPropertyList() {
      const filters = [];
      filtersViewsResult.data?.tenant.filters.forEach(filter => {
        filters.push({
          label: filter.name,
          value: filter.id,
          conditionSet: filter.conditionSet
        });
      });
      return [{
        'id': 'dropdownFilter',
        'defaultValue': filters?.[0]?.value,
        getFilter: filterId => {
          return filters.find(f => f.value === filterId);
        },
        'editor': {
          'sectionId': 'general.aiops_settings',
          'uiControl': {
            'type': 'DropDown',
            'name': 'dropdown Filter',
            'label': 'Filter',
            'ariaLabel': 'Filter',
            'options': filters
          }
        }
      }
      // {
      //   'id': 'sliderRefreshInterval',
      //   'type': '../UiSlider',
      //   'module': '../ui/UiSlider',
      //   'label': 'Refresh interval',
      //   'active': true,
      //   'connect': [true, false],
      //   'setp': 1,
      //   'start': [10],
      //   'range': {
      //     'min': 10,
      //     'max': 60
      //   }
      // }
      ];
    }
    getPropertyLayoutList() {
      return [];
    }
  }
  var _default = _exports.default = ButtonDynamicProperty;
});
//# sourceMappingURL=ButtonDynamicProperty.js.map