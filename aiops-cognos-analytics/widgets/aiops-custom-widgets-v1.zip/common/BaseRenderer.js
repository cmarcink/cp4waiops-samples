define(["exports", "./getProxy"], function (_exports, _getProxy) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  _getProxy = _interopRequireDefault(_getProxy);
  function _interopRequireDefault(e) { return e && e.__esModule ? e : { default: e }; }
  /* ******************************************************** {COPYRIGHT-TOP} ****
   * Copyright IBM Corp. 2024
   * 
   * This source code is licensed under the Apache-2.0 license found in the
   * LICENSE file in the root directory of this source tree.
   ********************************************************* {COPYRIGHT-END} ****/

  const getProxy = _getProxy.default.getProxy;
  class Renderer {
    constructor(options) {
      this.api = options.dashboardAPI;
      this.proxyHost = '';
    }
    initialize() {
      return getProxy(this.api.getDashboardInfo()).then(proxyHost => {
        this.proxyHost = proxyHost;
      });
    }
  }
  var _default = _exports.default = Renderer;
});
//# sourceMappingURL=BaseRenderer.js.map