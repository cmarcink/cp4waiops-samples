define(["exports", "./apiErrorCheck"], function (_exports, _apiErrorCheck) {
  "use strict";

  Object.defineProperty(_exports, "__esModule", {
    value: true
  });
  _exports.default = void 0;
  /* ******************************************************** {COPYRIGHT-TOP} ****
   * Copyright IBM Corp. 2024
   * 
   * This source code is licensed under the Apache-2.0 license found in the
   * LICENSE file in the root directory of this source tree.
   ********************************************************* {COPYRIGHT-END} ****/

  const tenantId = 'cfd95b7e-3bc7-4006-a4a8-a73a79c71255';
  const ALERT_SUMMARY = `query($tenantId: ID! $filter: String $groupBy: [String]) {
  tenant(id: $tenantId) {
    alertSummary(filter: $filter groupBy: $groupBy)
  }
}`;
  function getQuery() {
    return {
      query: `${ALERT_SUMMARY}`
    };
  }
  class AlertSummaryAPI {
    groupBy = ['severity'];
    constructor({
      groupBy,
      proxyHost = ''
    }) {
      this.groupBy = groupBy;
      this.proxyHost = proxyHost;
    }
    async getData({
      filter = ''
    }) {
      const GQL_API_PATH = this.proxyHost + '/api/p/hdm_ea_uiapi';
      const res = await (0, _apiErrorCheck.errorCheck)(fetch(GQL_API_PATH, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          'Origin': window.location.origin
        },
        mode: 'cors',
        credentials: 'include',
        body: JSON.stringify({
          ...getQuery(),
          variables: {
            tenantId,
            filter,
            groupBy: this.groupBy
          }
        })
      }));
      return await res.json();
    }
  }
  var _default = _exports.default = AlertSummaryAPI;
});
//# sourceMappingURL=AlertSummaryAPI.js.map